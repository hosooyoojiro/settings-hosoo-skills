#!/usr/bin/env bash
#
# bootstrap-prereqs.sh — 전제 도구(node, claude, codex) 자동 설치(best-effort).
# 새 컴퓨터에서 install.sh 가 맨 먼저 호출한다. 이미 있으면 건너뜀.
# 실패해도 전체 설치를 멈추지 않고 경고만 남긴다(set -e 미사용).
#
have() { command -v "$1" >/dev/null 2>&1; }
OS="$(uname -s)"

echo "▤ 전제 도구 확인"

# ── node ──────────────────────────────────────────────
if have node; then
  echo "  node: $(node -v)"
else
  echo "  node 없음 → 설치 시도"
  if have brew; then
    brew install node && echo "  node 설치(brew) 완료" || echo "  ⚠ brew node 설치 실패"
  else
    export NVM_DIR="${HOME}/.nvm"
    if [ ! -s "${NVM_DIR}/nvm.sh" ]; then
      echo "  nvm 설치..."
      curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash || echo "  ⚠ nvm 설치 실패"
    fi
    # shellcheck disable=SC1091
    [ -s "${NVM_DIR}/nvm.sh" ] && . "${NVM_DIR}/nvm.sh" && nvm install --lts && echo "  node 설치(nvm) 완료" || echo "  ⚠ node 설치 실패. 수동: https://nodejs.org"
  fi
fi

if ! have npm; then
  echo "  ⚠ npm 없음 → claude/codex 자동 설치 불가. node 설치를 먼저 확인하세요."
  return 0 2>/dev/null || exit 0
fi

# ── claude CLI ────────────────────────────────────────
if have claude; then
  echo "  claude: 설치됨"
else
  echo "  claude 설치..."
  npm install -g @anthropic-ai/claude-code && echo "  claude 설치 완료" || echo "  ⚠ 실패. 수동: npm i -g @anthropic-ai/claude-code"
fi

# ── codex CLI ─────────────────────────────────────────
if have codex; then
  echo "  codex: 설치됨"
else
  echo "  codex 설치..."
  npm install -g @openai/codex && echo "  codex 설치 완료" || echo "  ⚠ 실패. 수동: npm i -g @openai/codex"
fi

echo "  전제 도구 준비 완료."
