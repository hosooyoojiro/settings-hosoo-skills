---
name: server-convention-check
description: |
  서버 코드(Controller, Service, Repository, DTO, Exception) 작성 후 프로젝트 컨벤션 준수 여부를 검증합니다.
  "컨벤션 확인", "컨벤션 체크", "convention check", "컨벤션 맞는지" 등의 키워드가 있을 때 사용합니다.
  새로운 API를 작성하거나, 기존 API를 수정한 뒤 프로젝트 컨벤션과 맞는지 검증할 때 활용하세요.
---

# Server Convention Check

서버 코드가 프로젝트 컨벤션에 맞는지 검증하는 스킬입니다.

## 검증 프로세스

### 1. 컨벤션 문서 로드

반드시 다음 문서들을 읽고 기준으로 삼습니다:
- `docs/architecture.md` — 3-Tier 아키텍처 (Controller → Service → Repository)
- `docs/dto.md` — Request/Response DTO 작성 규칙
- `docs/naming.md` — 네이밍 컨벤션
- `docs/exceptions.md` — Exception 처리 패턴

### 2. 기존 코드 패턴 비교

같은 앱 내 동일한 HTTP 메서드를 사용하는 기존 API를 찾아 비교합니다:
- `@Post` → 기존 create API 패턴
- `@Patch` → 기존 update API 패턴
- `@Delete` → 기존 delete API 패턴
- `@Get` → 기존 get API 패턴

비교 대상은 같은 앱 디렉토리 내 controller에서 Grep으로 탐색합니다.

### 3. 체크 항목

#### 아키텍처
- [ ] Controller → Service → Repository 3-Tier 구조 준수
- [ ] Controller에 비즈니스 로직 없음
- [ ] Response DTO는 Service에서 인스턴스화

#### DTO
- [ ] Request DTO는 `nestjs-zod` 사용 (`createZodDto`)
- [ ] Param, Query, Body DTO를 하나의 파일에 정의
- [ ] 파일명: `{operation}-{feature}-request.dto.ts`
- [ ] Named export 사용 (default export 금지)
- [ ] Swagger 문서용 DTO 별도 클래스 작성

#### 네이밍
- [ ] Repository 메서드: `{operation}{Scope}{Purpose}` 패턴
- [ ] Request DTO: `{Operation}{Feature}{ParameterType}RequestDto`
- [ ] 변수명: `queryDto`, `bodyDto`, `paramDto` 사용
- [ ] 배열 상수: `_LIST` suffix

#### Exception
- [ ] API별 Exception 파일 분리
- [ ] Error Map + Exception Class + API 데코레이터 함수 3요소 완비
- [ ] 파일명: `{operation}-{feature}.exception.ts`

#### Swagger
- [ ] `@ApiOperation` (summary, description)
- [ ] 응답 데코레이터: POST → `@ApiCreatedResponse`, GET → `@ApiOkResponse`, DELETE → `@ApiNoContentResponse`
- [ ] `@ApiBody` (type 지정)
- [ ] Path param → `@ApiIdParam()` 공유 데코레이터 사용 (`:id` 패턴)

#### 기타
- [ ] `any` 타입 절대 금지
- [ ] `@Transactional()` 적절한 사용 (write 연산 시)
- [ ] `@Param()` 전체 객체 바인딩 (named param 금지)
- [ ] import 알파벳순 정렬
- [ ] `updatedAt` → `new Date()` 사용 (`sql\`CURRENT_TIMESTAMP\`` 금지)

### 4. 출력 형식

컨벤션에 맞지 않는 부분만 파일명:라인번호와 함께 보고합니다.

```
## 컨벤션 검증 결과

### 이슈 (N건)

| # | 심각도 | 파일:라인 | 내용 | 기존 패턴 참조 |
|---|--------|----------|------|---------------|
| 1 | HIGH   | controller.ts:55 | ... | project.controller.ts:194 |

### 확인 완료 항목
- 3-Tier 구조 ✓
- DTO 컨벤션 ✓
- ...
```

이슈가 없으면 "컨벤션 검증 통과" 로 간결하게 보고합니다.

## 주의사항

- 문서에 명시된 패턴과 기존 코드 패턴이 다를 경우, **기존 코드 패턴을 우선**합니다 (문서가 오래되었을 수 있음)
- 같은 feature 모듈 내 다른 API와의 일관성을 최우선으로 확인합니다
- 컨벤션 위반이 아닌 스타일 차이(있어도 되고 없어도 되는 것)는 보고하지 않습니다
