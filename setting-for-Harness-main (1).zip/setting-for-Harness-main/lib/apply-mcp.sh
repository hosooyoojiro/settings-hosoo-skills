#!/usr/bin/env bash
#
# apply-mcp.sh — system/mcp/mcp-servers.json 의 global MCP 서버를
# ~/.claude.json 의 mcpServers 에 병합한다. 토큰 플레이스홀더는 환경변수로 치환.
#
# 토큰 소스: secrets/tokens.env (있으면 source). 없으면 현재 환경변수 사용.
# 플레이스홀더(${SUPABASE_ACCESS_TOKEN} 등)가 안 채워지면 그 값 그대로 두고 경고.
#
set -euo pipefail

HARNESS_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MCP_SRC="${HARNESS_ROOT}/system/mcp/mcp-servers.json"
CLAUDE_JSON="${HOME}/.claude.json"
TOKENS="${HARNESS_ROOT}/secrets/tokens.env"

[ -f "$MCP_SRC" ] || { echo "MCP 소스 없음: $MCP_SRC"; exit 0; }
# shellcheck disable=SC1090
[ -f "$TOKENS" ] && source "$TOKENS"

# 플레이스홀더 치환 (환경변수 확장)
RENDERED="$(SUPABASE_ACCESS_TOKEN="${SUPABASE_ACCESS_TOKEN:-}" GITHUB_PAT="${GITHUB_PAT:-}" \
  python3 - "$MCP_SRC" <<'PY'
import json, os, re, sys
raw = open(sys.argv[1]).read()
def sub(m):
    return os.environ.get(m.group(1), m.group(0))
raw = re.sub(r'\$\{([A-Z_]+)\}', sub, raw)
print(raw)
PY
)"

# ~/.claude.json 에 global mcpServers 병합
python3 - "$CLAUDE_JSON" <<PY
import json, os, sys
rendered = json.loads('''$RENDERED''')
glob = rendered.get("global", {})
p = sys.argv[1]
doc = {}
if os.path.exists(p):
    try: doc = json.load(open(p))
    except Exception: doc = {}
doc.setdefault("mcpServers", {})
for k, v in glob.items():
    doc["mcpServers"][k] = v
json.dump(doc, open(p, "w"), indent=2, ensure_ascii=False)
left = [k for k,v in glob.items() if '\${' in json.dumps(v)]
print("MCP 병합:", ", ".join(glob.keys()) or "(없음)")
if left:
    print("⚠ 토큰 미치환:", ", ".join(left), "→ secrets/tokens.env 채우고 재실행")
PY
