#!/usr/bin/env bash
#
# install.sh — 새 컴퓨터에서 하네스를 설치(배포)한다.
#   git clone https://github.com/CastleJun/setting-for-Harness.git ~/work/.harness
#   cd ~/work/.harness && bash install.sh
#
# 하는 일:
#   1) 하네스가 ~/work/.harness 에 있는지 확인(가드훅·settings.json 절대경로 의존)
#   2) status 로 삭제 대상 미리보기 → 사용자 확인
#   3) Claude / Codex 로 push
#   4) 수동 후속(MCP 토큰) 안내
#
set -euo pipefail

EXPECTED="${HOME}/work/.harness"
HARNESS_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "▤ 하네스 설치  ($HARNESS_ROOT)"

if [ "$HARNESS_ROOT" != "$EXPECTED" ]; then
  echo "⚠  경고: 하네스가 $EXPECTED 이 아니라 $HARNESS_ROOT 에 있습니다."
  echo "   가드훅·settings.json 이 절대경로 $EXPECTED 를 참조하므로 반드시 그 위치에 두세요."
  echo "   계속하면 훅이 깨질 수 있습니다."
  printf "   그래도 진행? [y/N] "; read -r ans
  [ "$ans" = "y" ] || { echo "중단."; exit 1; }
fi

CLAUDE_ADP="${HARNESS_ROOT}/adapter/claude/bin/adapter-claude.sh"
CODEX_ADP="${HARNESS_ROOT}/adapter/codex/bin/adapter-codex.sh"

echo ""
echo "── [0/5] 전제 도구(node·claude·codex) ──"
bash "${HARNESS_ROOT}/lib/bootstrap-prereqs.sh" || echo "  ⚠ 일부 전제 도구 자동설치 실패(위 로그 확인). 계속 진행."

echo ""
echo "── [1/5] 배포 미리보기 (무엇이 바뀌는지) ──"
bash "$CLAUDE_ADP" status | grep -E 'deleting|tree|file|persona|status' || true
echo ""
echo "── Codex ──"
bash "$CODEX_ADP" status | grep -E 'deleting|tree|file|persona|status' || true

echo ""
printf "위 변경을 배포할까요? (harness 에 없는 스킬은 삭제됨) [y/N] "; read -r go
[ "$go" = "y" ] || { echo "중단. 배포 안 함."; exit 0; }

echo ""
echo "── [2/5] push (skill/role/command/system, 경로 자동 치환) ──"
bash "$CLAUDE_ADP" push
bash "$CODEX_ADP" push

echo ""
echo "── [3/5] HUD 플러그인 (claude-hud) ──"
if ls "${HOME}/.claude/plugins/cache/"*/claude-hud/*/ >/dev/null 2>&1; then
  echo "  이미 설치됨."
elif command -v claude >/dev/null 2>&1; then
  echo "  설치 중..."
  claude plugin marketplace add jarrodwatts/claude-hud >/dev/null 2>&1 || true
  claude plugin install claude-hud@claude-hud >/dev/null 2>&1 && echo "  완료" || echo "  ⚠ 설치 실패(수동: claude plugin install claude-hud@claude-hud)"
else
  echo "  ⚠ claude CLI 없음. 수동: claude plugin marketplace add jarrodwatts/claude-hud && claude plugin install claude-hud@claude-hud"
fi

echo ""
echo "── [4/5] MCP 주입 (~/.claude.json) ──"
if [ -f "${HARNESS_ROOT}/secrets/tokens.env" ]; then
  bash "${HARNESS_ROOT}/lib/apply-mcp.sh"
else
  echo "  secrets/tokens.env 없음 → MCP 건너뜀."
  echo "  cp secrets/tokens.env.example secrets/tokens.env 후 토큰 채우고 재실행하면 자동 주입."
fi

echo ""
echo "✓ 설치 완료. 새 세션을 시작하세요."
echo "  (grill-me 등 추가 스킬은 skill/ 로 vendor 되어 있으면 위 push 로 이미 배포됨.)"
