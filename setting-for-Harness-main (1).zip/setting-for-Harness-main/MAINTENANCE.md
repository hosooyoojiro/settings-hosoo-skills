# MAINTENANCE — .harness 유지보수

사용법은 [README.md](README.md). 이 문서는 하네스 자체를 손볼 때의 규칙.

## 배포 파이프라인

- 원본 = `~/work/.harness/`. 대상 = `~/.claude` / `~/.codex`.
- `adapter/*/bin/adapter-*.sh` 가 `lib/harness-lib.sh` 를 source 해 `status`/`push` 수행.
- 매핑은 각 adapter 의 `MAP` 배열(`type|src|dst`). type = `tree`(--delete 미러) / `file`(단일 파일) / `persona`(role .md → skills/<name>/SKILL.md).

## 새 자산 추가 절차

1. `skill/<name>/SKILL.md` (또는 `role/<name>.md`, `command/<name>.md`) 추가.
2. `adapter-*.sh status` 로 변경 확인.
3. 커밋.
4. `adapter-*.sh push` 로 배포.

## 매핑을 바꿀 때

- adapter 스크립트의 `MAP` 배열만 수정. 로직은 `lib/harness-lib.sh` 공용.
- `tree` 는 `--delete` 라 파괴적. 새 대상 추가 시 `status` 로 삭제 목록 반드시 선확인.

## 가드 훅

- `plugin/hooks/guard-write.sh` — `~/.claude`·`~/.codex` 직접 편집(Write/Edit) 차단.
- `system/settings.json` PreToolUse 에 절대경로로 등록. 훅 위치를 옮기면 settings.json 경로도 함께 수정.

## 시크릿

- `system/mcp/mcp-servers.json` 토큰은 `${...}` 플레이스홀더 유지. 실토큰 커밋 금지.
- `.gitignore`: `*.snapshot.json`, `.omc/`, `secrets/`, `.env`.
- 커밋 전 `grep -rIE 'sbp_[A-Za-z0-9]{10}|ghp_[A-Za-z0-9]{10}' . --exclude-dir=.git` 로 확인.

## 미구현 (레퍼런스 대비)

- `daemon/`, `test/`, `docs/`, `memory/` 는 뼈대만. 필요 시 채운다.
- 워크플로 스킬은 grill-me v1.2 설치 후 실제 쓰는 것 기준으로 채운다.
