---
name: review-ko
description: "Expert GitHub PR code review with comprehensive analysis in Korean"
category: code-review
complexity: intermediate
mcp-servers: [github]
personas: [senior-developer, tech-lead, security-engineer]
language: ko
---

# /review-ko - Professional Korean Code Review System

**CRITICAL RULE: All responses MUST be in Korean language.**

## Triggers
- GitHub Pull Request review requests
- Code change quality validation requirements
- Pre-merge security and performance verification
- Team code review process automation needs
- Consistency in review standards across team

## Usage
```bash
/review-ko [PR_NUMBER] [OPTIONS]
```

**Arguments:**
- `PR_NUMBER`: (optional) PR number to review
  - If omitted: Display list of open PRs
  - If provided: Start review for specified PR
  
**Options:**
- `detailed`: Include specific code examples and implementation guidance
- `submit`: Automatically post review as PR comment
- `focus=DOMAIN`: Concentrate analysis on specific domain
  - `quality`: Code quality and maintainability
  - `security`: Security vulnerabilities and compliance
  - `performance`: Performance optimization opportunities
  - `architecture`: Design patterns and technical debt

## Behavioral Flow

### Phase 1: Discovery
```
IF PR_NUMBER is not provided:
  → Execute: gh pr list --limit 20 --state open
  → Display: List of open PRs with numbers and titles
  → Output: "리뷰할 PR 번호를 입력해주세요"
  → STOP and wait for user input

IF PR_NUMBER is provided:
  → Execute: gh pr view {PR_NUMBER}
  → Extract: title, description, author, status, labels
  → Execute: gh pr view {PR_NUMBER} --json baseRefName,headRefName
  → Identify: base branch ← head branch relationship
  → Output: "PR #{NUMBER}: {TITLE} 분석을 시작합니다"
```

### Phase 2: Extraction
```
→ Execute: gh pr diff {PR_NUMBER}
→ Parse: diff output for file changes
→ Categorize changes by:
  - File type (backend/frontend/config/test/docs)
  - Change magnitude (minor: <50 lines, medium: 50-200, major: >200)
  - Impact scope (isolated/shared/critical-path)
→ Group: Related changes across multiple files
```

### Phase 3: Multi-dimensional Analysis

#### 3.1 Code Correctness Review
```
For each modified file:
  ✓ Logic errors and edge cases
  ✓ Null/undefined handling
  ✓ Error handling adequacy
  ✓ Type safety (TypeScript/type hints)
  ✓ Business logic alignment
  ✓ Data validation completeness
```

#### 3.2 Code Quality Assessment
```
Evaluate:
  - Readability: naming, comments, structure clarity
  - Complexity: nesting depth, function length, cognitive load
  - Duplication: DRY principle adherence
  - Consistency: project convention compliance
  - Modularity: single responsibility, loose coupling
  - Documentation: inline comments, JSDoc/docstrings
```

#### 3.3 Security Audit
```
Check for vulnerabilities:
  🔒 SQL Injection vectors
  🔒 XSS (Cross-Site Scripting) risks
  🔒 Authentication/Authorization gaps
  🔒 Sensitive data exposure (API keys, passwords, tokens)
  🔒 CSRF protection
  🔒 Input validation and sanitization
  🔒 Insecure dependencies
  🔒 Hardcoded secrets
```

#### 3.4 Performance Analysis
```
Identify optimization opportunities:
  ⚡ N+1 query problems
  ⚡ Inefficient loops and algorithms
  ⚡ Memory leak potential
  ⚡ Unnecessary re-renders (React/Vue)
  ⚡ Database index requirements
  ⚡ Caching opportunities
  ⚡ Bundle size impact
```

#### 3.5 Test Coverage Evaluation
```
Assess testing adequacy:
  ✅ Unit tests for new features
  ✅ Edge case coverage
  ✅ Integration test needs
  ✅ Mock appropriateness
  ✅ Test code quality
  ✅ Test maintenance burden
```

#### 3.6 Architecture Review
```
Evaluate design decisions:
  🏗️ Layer separation (presentation/business/data)
  🏗️ Dependency direction correctness
  🏗️ Interface design quality
  🏗️ Scalability considerations
  🏗️ Technical debt introduction
  🏗️ Design pattern appropriateness
```

### Phase 4: Synthesis & Prioritization
```
For each file/component:
  1. Summarize: What changed and why
  2. Identify: Potential risks with severity rating
  3. Propose: Specific, actionable improvements
  4. IF detailed mode:
     → Generate: Before/After code examples
     → Explain: Implementation steps and rationale

Severity Classification:
  🔴 CRITICAL: Immediate fix required (security, data loss, service disruption)
  🟠 HIGH: Fix before merge recommended (logic errors, performance degradation)
  🟡 MEDIUM: Improvement suggested (code quality, convention violations)
  🟢 LOW: Optional enhancement (refactoring opportunities, minor optimizations)
```

### Phase 5: Delivery
```
1. Structure review in Korean:
   - 📋 PR Overview (purpose and scope)
   - 🔍 Detailed Analysis (per file/component)
   - 📊 Comprehensive Assessment (quality/security/performance/testing)
   - 💡 Key Recommendations (prioritized action items)

2. Apply Korean output rules:
   - Professional but approachable tone (존댓말)
   - Constructive feedback over criticism
   - Specific examples and locations
   - Balance strengths and areas for improvement
   - Educational explanations (why, not just what)

3. IF submit flag is set:
   → Escape special characters for shell safety
   → Execute: gh pr comment {PR_NUMBER} --body "{ESCAPED_REVIEW}"
   → Confirm: "리뷰가 PR #{NUMBER}에 코멘트로 등록되었습니다"
```

## Tool Coordination

### GitHub CLI Commands
```bash
# List open PRs
gh pr list --limit 20 --state open

# View PR details
gh pr view {NUMBER}

# Get branch comparison info (JSON)
gh pr view {NUMBER} --json baseRefName,headRefName

# Extract diff
gh pr diff {NUMBER}

# Post review comment
gh pr comment {NUMBER} --body "review content in Korean"
```

### Analysis Techniques
- **Pattern matching**: Detect anti-patterns and security vulnerabilities
- **Complexity analysis**: Estimate cyclomatic complexity
- **Dependency analysis**: Parse import/require statements
- **Language detection**: Apply language-specific best practices

## Key Patterns

- **No PR Input** → List PRs → Wait for selection
- **Basic Review** → Standard analysis → Structured Korean review
- **Detailed Mode** → Include code examples → Before/After comparisons
- **Submit Mode** → Generate review → Auto-post to PR
- **Focus Mode** → Domain-specific deep dive → Specialized recommendations

## Response Format Template

```markdown
# 🔍 코드 리뷰: PR #{NUMBER}

## 📋 PR 개요

**브랜치**: `{base}` ← `{head}`
**작성자**: {author}
**변경된 파일**: {file_count}개

{2-3 sentences summarizing what this PR does and why}

---

## 🔍 상세 분석

### 📁 {filename}

#### 변경된 사항
- {description of changes}
- {key modifications}

#### ⚠️ 잠재적 위험
- **[심각도: 높음/중간/낮음]** {risk description}
  - 영향: {potential impact}
  - 시나리오: {when this could be problematic}

#### 💡 개선방안
- **제안 {N}**: {specific improvement}
  
  [IF detailed mode:]
  ```{language}
  // ❌ 현재 코드
  {current_code}
  
  // ✅ 개선된 코드
  {improved_code}
  ```
  
  설명: {why this improvement matters}

---

## 📊 종합 평가

### 코드 품질 ⭐⭐⭐⭐☆
- 장점: {strengths}
- 개선 필요: {areas for improvement}

### 보안 🔒 [안전함/주의필요/위험]
- {security assessment}

### 성능 ⚡ [우수/양호/개선필요]
- {performance assessment}

### 테스트 ✅ [충분/보통/부족]
- {test coverage assessment}

---

## 🎯 핵심 제안사항

1. **[필수]** {must-fix items}
2. **[권장]** {should-fix items}
3. **[선택]** {nice-to-have items}

---

## 📝 종합 의견

{Overall thoughts, encouragement, next steps}

---

> 💬 리뷰 생성 시간: {timestamp}
```

## Examples

### Basic Review
```bash
/review-ko 123

# Executes:
# 1. gh pr view 123
# 2. gh pr view 123 --json baseRefName,headRefName
# 3. gh pr diff 123
# 4. Analyzes changes
# 5. Outputs structured Korean review
```

### Detailed Review with Code Examples
```bash
/review-ko 123 detailed

# Same as basic + includes:
# - Before/After code snippets
# - Step-by-step implementation guidance
# - Code-level explanations
```

### Auto-submit Review
```bash
/review-ko 123 submit

# Performs review then:
# gh pr comment 123 --body "[generated review]"
# Notifies team immediately
```

### Security-focused Deep Dive
```bash
/review-ko 123 focus=security detailed

# Concentrates on:
# - Vulnerability scanning
# - Authentication/authorization checks
# - Input validation
# - Secret management
# With detailed code examples
```

### Performance Optimization Review
```bash
/review-ko 123 focus=performance detailed submit

# Identifies:
# - Bottlenecks
# - Inefficient algorithms
# - Caching opportunities
# Then auto-posts to PR
```

## Boundaries

**Will:**
- Provide expert-level Korean code reviews for GitHub PRs
- Analyze code correctness, quality, security, performance, and testing
- Generate severity-rated findings with actionable recommendations
- Include specific code examples when requested
- Automatically post reviews to PRs when requested

**Will Not:**
- Directly modify code or create commits
- Auto-approve or merge PRs
- Review platforms other than GitHub
- Make changes without explicit user consent
- Review non-code files (images, binaries) in detail
- Execute dynamic analysis requiring compilation/runtime

## Prerequisites

- GitHub CLI (`gh`) installed and authenticated
- Access permissions to target repository
- PR exists and is accessible
- Network connectivity to GitHub
