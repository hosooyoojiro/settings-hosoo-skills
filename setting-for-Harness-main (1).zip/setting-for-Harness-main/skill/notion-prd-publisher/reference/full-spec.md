# Notion PRD Publisher Skill Specification

## 1. 개요

### 스킬명

`notion-prd-publisher`

### 목적

Superpowers `brainstorming`, Ouroboros `interview/seed`, Matt Pocock `grill-with-docs/to-spec`, 수동 작성 또는 기타 PRD 생성기를 통해 **완성되고 계층까지 확정된 PRD 문서**를 Notion MCP로 `PRDs` 데이터베이스에 생성하거나 업데이트한다.

이 스킬은 PRD 생성기가 아니다. Wiki와 Figma를 다시 분석해 요구사항을 만들거나, 한 문서와 여러 문서 중 어느 구조가 적절한지 판단하지 않는다.

```text
Wiki + Figma
→ 선행 PRD 생성 워크플로우
→ 단일/다중 PRD 구조 제안
→ 사용자 확인
→ 완성된 PRD + publication manifest
→ notion-prd-publisher
→ Notion PRDs DB
```

### 핵심 원칙

- PRD 생성과 Notion 발행을 분리한다.
- 단일 PRD인지 다중 PRD인지는 선행 생성 단계에서 사용자 확인을 거쳐 확정한다.
- Publisher는 확정된 문서 경계와 부모 관계를 그대로 반영한다.
- Markdown Heading을 근거로 문서를 자동 분리하지 않는다.
- PRD 본문에 `문서 이력`, `개요` 등 고정 섹션을 강제하지 않는다.
- `Main PRD`, `Feature PRD` 같은 문서 타입을 만들지 않는다.
- Projects DB를 만들지 않는다.
- 상위·하위 관계는 `Parent PRD` 자기참조 Relation으로만 표현한다.
- 원문을 임의로 요약하거나 재작성하지 않는다.

---

## 2. 책임 범위

### 포함

- 완성된 PRD 문서와 publication manifest 검증
- Notion `PRDs` 데이터베이스 조회
- PRD 페이지 신규 생성 또는 기존 페이지 업데이트
- Markdown을 Notion 블록으로 변환
- 입력된 `parent_key`를 `Parent PRD` Relation으로 연결
- 서비스, 상태, Owner, 일정, Wiki, Figma 속성 저장
- 중복 문서 검색과 안전한 Upsert
- 생성·수정된 Notion 페이지 링크 반환

### 제외

- Wiki/Figma를 읽어 PRD를 새로 작성하는 작업
- 요구사항 인터뷰
- 단일 PRD와 다중 PRD 중 적절한 구조 판단
- PRD 내부 기능을 임의로 별도 문서로 분리
- 여러 PRD를 임의로 하나로 병합
- 구현 계획, 개발 티켓 또는 코드 생성
- Figma 디자인 변경 제안
- 사용자 승인 없는 Notion 스키마 변경

---

## 3. 선행 PRD 생성 단계의 계약

선행 워크플로우는 Notion Publisher를 호출하기 전에 다음을 완료해야 한다.

1. Wiki와 Figma를 분석한다.
2. PRD를 하나로 만들지, 기능별 여러 PRD로 만들지 제안한다.
3. 권장 구조와 분리 이유를 사용자에게 설명한다.
4. 사용자 답변으로 문서 구조를 확정한다.
5. 각 문서의 제목, 본문, 부모 관계를 publication manifest로 만든다.
6. 완성된 Markdown 문서와 manifest를 Publisher에 전달한다.

### 구조 확인 질문 예시

```text
Canvas List 요구사항을 다음 중 어떤 구조로 생성할까요?

1. Canvas List 단일 PRD
   - 모든 요구사항을 한 페이지의 섹션으로 구성

2. Canvas List와 기능별 하위 PRD
   - Canvas List
     - Banner
     - Section 1
     - Section 2

분석상 권장 구조: 1번
이유: 각 항목이 동일 화면과 사용자 흐름을 공유하며 독립 배포 단위가 아님
```

Publisher는 이 질문을 다시 수행하지 않는다. 다만 manifest가 누락되거나 문서 경계가 모호하면 자동 추론하지 않고 입력 보완을 요청한다.

---

## 4. Publisher 입력 계약

### 4.1 필수 최상위 값

```yaml
service: Canvas
status: Approved
documents: []
```

### 4.2 단일 PRD 예시

```yaml
service: Canvas
status: Approved
wiki_url: https://notion.so/source-wiki
figma_url: https://figma.com/design/file?node-id=1-2
owner: optional
target_date: optional
documents:
  - key: canvas-list
    title: Canvas List
    body: |
      # Canvas List

      ...완성된 PRD Markdown 전체...
```

동작:

```text
PRDs DB
└─ Canvas List
```

`Canvas List` 본문의 Heading, 표, 목록, 체크박스는 모두 한 페이지의 본문 블록으로 저장한다.

### 4.3 다중 PRD 예시

```yaml
service: Canvas
status: Approved
wiki_url: https://notion.so/source-wiki
figma_url: https://figma.com/design/file?node-id=1-2
documents:
  - key: canvas-list
    title: Canvas List
    body: |
      ...Canvas List PRD...

  - key: banner
    title: Banner
    parent_key: canvas-list
    figma_url: https://figma.com/design/file?node-id=10-20
    body: |
      ...Banner PRD...

  - key: section-1
    title: Section 1
    parent_key: canvas-list
    figma_url: https://figma.com/design/file?node-id=30-40
    body: |
      ...Section 1 PRD...
```

동작:

```text
Canvas List
├─ Banner
└─ Section 1
```

### 4.4 문서 항목 필드

| 필드 | 필수 | 설명 |
|---|---:|---|
| `key` | 필수 | manifest 내부 고유 식별자 |
| `title` | 필수 | Notion PRD 페이지 제목 |
| `body` | 필수 | 완성된 Markdown PRD 본문 |
| `parent_key` | 선택 | 부모 문서의 `key` |
| `wiki_url` | 선택 | 해당 문서에만 적용되는 Wiki URL |
| `figma_url` | 선택 | 해당 문서 대상 Figma 또는 Frame URL |
| `owner` | 선택 | 문서별 Owner override |
| `target_date` | 선택 | 문서별 목표 일정 override |
| `status` | 선택 | 문서별 상태 override |
| `notion_url` | 선택 | 기존 PRD를 정확히 업데이트할 때 사용할 Notion 페이지 URL |

문서별 값이 없으면 최상위 공통값을 상속한다.

### 4.5 입력 검증 규칙

- `documents`가 한 건이면 단일 PRD 한 페이지로 발행한다.
- `documents`가 여러 건이면 각 항목을 별도 PRD 페이지로 발행한다.
- `parent_key`가 있을 때만 Parent PRD Relation을 연결한다.
- 모든 `parent_key`는 같은 manifest 안의 유효한 `key`를 참조해야 한다.
- 순환 참조를 허용하지 않는다.
- Heading 수, 본문 길이, Figma Frame 수를 기준으로 자동 분리하지 않는다.
- 하나의 `body` 안에 여러 문서처럼 보이는 내용이 있어도 자동 분리하지 않는다.
- 문서 경계나 부모 관계가 불명확하면 Notion 쓰기를 시작하기 전에 입력 보완을 요청한다.

---

## 5. Notion 데이터베이스 구조

데이터베이스 이름: `PRDs`

| 속성명 | Notion 타입 | 필수 | 설명 |
|---|---|---:|---|
| 제목 | Title | 필수 | PRD 제목 |
| 서비스 | Select | 필수 | AI Studio / Stock / Canvas / Match / Shared |
| 상태 | Status | 필수 | Draft / Review / Approved / In Development / Released / Archived |
| Parent PRD | Self Relation → PRDs | 선택 | manifest의 `parent_key`에 해당하는 부모 페이지 |
| Child PRDs | Parent PRD 역방향 Relation | 자동 | 하위 PRD 목록 |
| Owner | Person | 선택 | PRD 책임자 |
| 목표 일정 | Date | 선택 | PRD 목표 일정 |
| 기획 Wiki | URL | 선택 | PRD 생성에 사용된 Wiki 원본 |
| Figma | URL | 선택 | PRD 대상 Figma 또는 Frame |
| 생성일 | Created time | 자동 | 생성 시각 |
| 수정일 | Last edited time | 자동 | 최종 수정 시각 |

### 서비스 옵션

```text
AI Studio
Stock
Canvas
Match
Shared
```

### 상태 옵션

```text
Draft
Review
Approved
In Development
Released
Archived
```

### 의도적으로 만들지 않는 속성

- Project Relation
- PRD 유형
- Main PRD 여부
- Feature PRD 여부
- PRD ID
- 문서 이력
- 개요
- 구현 계획
- Ticket URL
- 문서 버전

`문서 이력`, `개요` 등은 데이터베이스 속성이나 필수 템플릿이 아니다. 입력 PRD 본문에 존재할 때만 본문 블록으로 저장한다.

---

## 6. PRD 본문 변환 규칙

완성된 Markdown 구조를 가능한 한 동일한 Notion 블록으로 변환한다.

| Markdown | Notion 블록 |
|---|---|
| 첫 번째 `# 제목` | 페이지 Title과 같으면 본문 중복 제거 가능 |
| `## 제목` | Heading 1 |
| `### 제목` | Heading 2 |
| `#### 제목` | Heading 3 |
| 일반 문단 | Paragraph |
| `- 항목` | Bulleted list |
| `1. 항목` | Numbered list |
| `- [ ] 항목` | To-do |
| Markdown Table | Table block |
| 인용 또는 주의 | Quote 또는 Callout |
| 코드 | Inline code 또는 Code block |
| 링크 | URL을 보존한 Rich text |

### 본문 보존 원칙

- 고정 PRD 템플릿을 삽입하지 않는다.
- 입력에 없는 `문서 이력`, `개요`, `배경`, `Acceptance Criteria`를 임의로 추가하지 않는다.
- 입력에 존재하는 Heading 순서를 유지한다.
- 표의 행과 열을 누락하지 않는다.
- 체크박스 상태를 유지한다.
- 링크와 참조 문서명을 유지한다.
- 미결정 사항을 삭제하거나 확정 사항으로 바꾸지 않는다.
- 문장을 임의로 요약하거나 표현을 다시 작성하지 않는다.
- Notion 호환을 위한 최소 서식 정규화만 허용한다.

---

## 7. 실행 워크플로우

### 1단계: 입력 검증

- `service`, `status`, `documents` 존재 여부 확인
- 모든 문서의 `key`, `title`, `body` 확인
- `key` 중복 확인
- `parent_key` 참조 유효성 확인
- 순환 부모 관계 확인
- 문서 경계가 명시되어 있는지 확인

검증 실패 시 Notion에 일부만 쓰지 말고 필요한 입력을 먼저 요청한다.

### 2단계: PRDs DB 확인

- 대상 `PRDs` DB를 찾는다.
- 필수 속성과 Select/Status 옵션을 확인한다.
- 스키마가 다르면 자동 변경하지 않고 차이를 보고한다.
- 사용자가 명시적으로 허용한 경우에만 누락 속성을 추가한다.

### 3단계: 기존 PRD 검색

기본 중복 검색 키:

```text
제목 + 서비스 + Parent PRD
```

검색 결과:

- 0건: 신규 생성
- 1건: 요청 모드에 따라 업데이트 또는 중복 경고
- 2건 이상: 임의 선택하지 않고 후보 확인 요청

### 4단계: 부모부터 Upsert

1. `parent_key`가 없는 루트 문서를 먼저 생성하거나 조회한다.
2. 루트 문서 페이지 ID를 manifest key와 매핑한다.
3. 부모가 준비된 하위 문서를 생성하거나 조회한다.
4. `Parent PRD` Relation을 연결한다.
5. 모든 문서가 처리될 때까지 계층 순서대로 반복한다.

### 5단계: 본문 발행

- Markdown을 Notion 블록으로 변환한다.
- 문서별 메타데이터를 설정한다.
- 업데이트 시 기존 수동 작성 내용을 임의로 삭제하지 않는다.
- 안전한 전체 교체 기준이 없으면 충돌 항목을 사용자에게 확인한다.

### 6단계: 결과 확인

- 생성된 페이지 수
- 업데이트된 페이지 수
- 건너뛴 페이지 수
- Parent PRD 연결 성공 여부
- 실패한 항목과 이유
- 생성 또는 수정된 Notion 링크

---

## 8. 동작 모드

### Create

동일 문서가 있으면 새로 만들지 않고 중복 후보를 보고한다.

### Update

기존 페이지가 정확히 한 건 확인될 때만 업데이트한다.

### Upsert

기존 페이지가 정확히 한 건이면 업데이트하고, 없으면 생성한다.

기본값은 `Upsert`를 권장한다.

---

## 9. 오류 처리

### Notion MCP 연결 실패

- 저장 예정 manifest와 Markdown을 그대로 반환한다.
- 저장되지 않았음을 명확히 알린다.
- 가짜 Notion 링크를 만들지 않는다.

### PRDs DB를 찾지 못한 경우

- 사용자가 DB 생성 권한을 명시했다면 정의된 스키마로 생성한다.
- 권한이 불명확하면 대상 DB 또는 생성 위치를 요청한다.

### Relation 연결 실패

- 페이지 생성 성공과 Relation 실패를 분리해 보고한다.
- Parent PRD를 일반 텍스트로 대체하지 않는다.
- 재시도에 필요한 부모·자식 페이지 링크를 반환한다.

### Manifest 불명확

- Markdown Heading을 근거로 문서를 임의 분리하지 않는다.
- 선행 PRD 생성 단계에서 단일/다중 구조를 다시 확정하도록 요청한다.

---

## 10. 결과 보고 형식

### 단일 PRD

```text
Notion 반영 완료

서비스: Canvas
PRD: Canvas List
작업: 생성 1 / 업데이트 0 / 건너뜀 0
Parent PRD: 없음
링크: {Notion URL}
```

### 다중 PRD

```text
Notion 반영 완료

서비스: Canvas
구조:
- Canvas List
  - Banner
  - Section 1

작업: 생성 3 / 업데이트 0 / 건너뜀 0
Parent PRD 연결: 2/2 성공
링크:
- Canvas List: {URL}
- Banner: {URL}
- Section 1: {URL}
```

---

## 11. 완료 기준

다음을 모두 만족해야 한다.

- 완성된 PRD만 입력으로 받는다.
- 단일/다중 PRD 구조가 manifest에 명시되어 있다.
- 구조가 불명확하면 자동 추론하지 않는다.
- PRD 본문에 고정 섹션을 강제하지 않는다.
- `PRDs` DB 하나만 사용한다.
- 서비스와 상태를 저장한다.
- `Parent PRD` 자기참조 Relation을 연결할 수 있다.
- 단일 PRD를 한 페이지로 발행할 수 있다.
- 다중 PRD를 여러 페이지와 부모·자식 관계로 발행할 수 있다.
- Markdown Heading, 표, 목록, 체크박스, 링크를 보존한다.
- 기존 페이지를 안전하게 생성 또는 업데이트한다.
- 결과 페이지 링크와 실패 내용을 정확히 보고한다.

---

## 12. 실제 사용 Flow

이 스킬은 **PRD 생성이 끝난 뒤** 호출한다. 전체 흐름은 다음 상태를 순서대로 통과한다.

```text
SOURCE_READY
→ STRUCTURE_CONFIRMED
→ PRD_FINALIZED
→ PUBLISH_PREVIEWED
→ PUBLISH_CONFIRMED
→ PUBLISHED
```

### 12.1 최초 설정 — 한 번만 수행

1. Notion MCP를 연결하고 쓰기 권한을 확인한다.
2. 발행 대상 `PRDs` 데이터베이스를 생성하거나 기존 DB를 지정한다.
3. Publisher가 DB 속성, 상태 옵션, 서비스 옵션을 검증한다.
4. 대상 DB가 여러 개라면 정확한 DB URL을 스킬 설정 또는 실행 입력에 고정한다.
5. 검증이 끝난 뒤에만 실제 PRD 발행 Flow를 시작한다.

초기 설정 결과 예시:

```yaml
notion_database_url: https://www.notion.so/...
database_name: PRDs
schema_status: valid
```

### 12.2 신규 PRD 발행 Flow

#### 단계 1. PRD 생성기 실행

사용자는 선행 PRD 생성기에 최소 다음 자료를 제공한다.

```text
- 생성 대상: 예) Canvas List
- 서비스: 예) Canvas
- 기획 Wiki URL
- Figma URL 또는 대상 Frame URL
```

도구별 PRD 완성 지점:

```text
Superpowers: brainstorming 완료
Ouroboros: interview → seed 완료
Matt Pocock Skills: grill-with-docs → to-spec 완료
기타: 사용자가 최종 PRD로 승인한 문서
```

#### 단계 2. 문서 구조 확인

PRD 생성기는 Wiki와 Figma를 분석한 뒤 다음 중 어떤 구조가 적절한지 제안한다.

```text
A. 단일 PRD
Canvas List

B. 여러 PRD
Canvas List
├─ Banner
├─ Section 1
└─ Section 2
```

다음을 반드시 사용자에게 보여준다.

- 권장 구조
- 문서별 책임 범위
- 분리 또는 유지 이유
- 최종 생성될 문서 트리

사용자가 구조를 승인하기 전에는 최종 PRD나 publication manifest를 확정하지 않는다.

#### 단계 3. PRD 최종화

승인된 구조에 따라 PRD 생성기가 다음을 만든다.

```text
- 완성된 PRD 본문
- 문서별 제목
- 문서별 key
- 부모 문서가 있으면 parent_key
- 서비스와 상태
- Wiki/Figma 출처
- 선택값: Owner, 목표 일정
```

PRD 생성기는 문서 개수와 부모 관계를 `documents[]`에 명시한다. Publisher가 Heading이나 문서 길이로 경계를 추론하게 두지 않는다.

#### 단계 4. Publisher 호출

같은 세션에서는 다음처럼 요청한다.

```text
방금 확정한 PRD를 notion-prd-publisher로 발행해줘.
서비스는 Canvas, 상태는 Review, 모드는 Upsert로 처리해줘.
Notion에 쓰기 전에 생성·업데이트 예정 구조를 한 번 보여줘.
```

다른 세션이나 다른 하네스에서는 manifest와 Markdown 파일을 함께 전달한다.

```text
notion-prd-publisher로 아래 publication manifest와 PRD 파일을 발행해줘.
대상 DB: {PRDs DB URL}
모드: Upsert
```

#### 단계 5. 사전 검증과 미리보기

Publisher는 Notion에 쓰기 전에 다음을 검증한다.

- 필수 메타데이터
- 문서 key 중복
- 부모 key 유효성
- 순환 Relation
- 대상 DB 스키마
- 기존 페이지 존재 여부
- Create / Update / Skip 예정 건수

미리보기 예시:

```text
Notion 반영 예정

서비스: Canvas
상태: Review
모드: Upsert

구조:
- Canvas List — 생성 예정
  - Banner — 생성 예정
  - Section 1 — 기존 문서 업데이트 예정

생성 2 / 업데이트 1 / 건너뜀 0
```

#### 단계 6. 사용자 확인

기본 동작은 **한 번의 쓰기 확인**을 받는 것이다.

```text
이 구조로 Notion에 반영할까요?
```

사용자가 같은 요청에서 명시적으로 즉시 발행을 승인했다면 별도의 반복 확인을 요구하지 않아도 된다. 구조나 대상 DB가 달라졌다면 반드시 다시 확인한다.

#### 단계 7. Notion 발행

확인 후 다음 순서로 처리한다.

1. 부모가 없는 PRD를 먼저 생성 또는 업데이트한다.
2. 생성된 Notion 페이지 ID를 문서 key에 매핑한다.
3. 하위 PRD를 생성 또는 업데이트한다.
4. `Parent PRD` Relation을 연결한다.
5. Markdown 본문을 Notion 블록으로 반영한다.
6. 서비스, 상태, Owner, 목표 일정, Wiki, Figma 속성을 설정한다.
7. 생성·수정된 링크와 실패 항목을 반환한다.

### 12.3 단일 PRD 사용 예

```yaml
service: Canvas
status: Review
mode: Upsert
wiki_url: https://notion.so/...
figma_url: https://figma.com/...
documents:
  - key: canvas-list
    title: Canvas List
    body: |
      ...완성된 Canvas List PRD...
```

결과:

```text
PRDs DB
└─ Canvas List
```

PRD 본문의 `A. 캔버스 리스트`, `B. 템플릿 카드` 등의 Heading은 같은 Notion 페이지 안에 유지한다.

### 12.4 다중 PRD 사용 예

```yaml
service: Canvas
status: Review
mode: Upsert
wiki_url: https://notion.so/...
figma_url: https://figma.com/...
documents:
  - key: canvas-list
    title: Canvas List
    body: |
      ...Canvas List 공통 PRD...

  - key: banner
    title: Banner
    parent_key: canvas-list
    body: |
      ...Banner PRD...

  - key: section-1
    title: Section 1
    parent_key: canvas-list
    body: |
      ...Section 1 PRD...
```

결과:

```text
Canvas List
├─ Banner
└─ Section 1
```

### 12.5 기존 PRD 업데이트 Flow

1. PRD 생성기 또는 사용자가 기존 PRD를 수정한다.
2. 기존 발행 결과의 Notion URL을 `notion_url`로 함께 전달한다.
3. Publisher를 `Update` 또는 `Upsert` 모드로 호출한다.
4. Publisher가 업데이트 대상과 변경 범위를 미리 보여준다.
5. 사용자 확인 후 본문과 속성을 업데이트한다.
6. 결과 링크를 다시 반환한다.

권장 요청:

```text
이 수정된 PRD를 기존 Notion 페이지에 업데이트해줘.
새 페이지를 만들지 말고 아래 Notion URL을 대상으로 처리해줘.
{Notion URL}
```

`notion_url`이 없으면 `제목 + 서비스 + Parent PRD`로 검색한다. 후보가 둘 이상이면 임의 업데이트하지 않고 사용자에게 선택을 요청한다.

### 12.6 문서 분리 또는 병합 변경

#### 단일 PRD를 여러 PRD로 분리

- PRD 생성 단계에서 새로운 문서 트리를 다시 승인받는다.
- Publisher는 기존 상위 페이지를 업데이트하고 신규 하위 페이지를 생성한다.
- 새 하위 페이지에 `Parent PRD`를 연결한다.

#### 여러 PRD를 하나로 병합

- Publisher는 manifest에서 사라진 기존 페이지를 자동 삭제하거나 Archive하지 않는다.
- 기존 하위 페이지를 유지, Archive, 삭제 중 어떻게 처리할지 사용자에게 명시적으로 확인한다.
- 삭제 기능이 스킬 범위에 없다면 링크와 수동 조치 목록만 반환한다.

### 12.7 상태 운영 규칙

권장 기본값:

```text
초기 생성물: Draft
사람 검토 요청: Review
명시적 승인 완료: Approved
개발 시작: In Development
배포 완료: Released
사용 종료: Archived
```

Publisher는 생성된 문서라는 이유만으로 상태를 `Approved`로 설정하지 않는다. 상태가 없으면 기본 `Draft`를 사용하거나 사용자에게 한 번 확인한다.

### 12.8 실패 시 재실행

- 일부 페이지만 생성되고 실패한 경우 성공한 링크와 실패한 key를 함께 반환한다.
- 재실행 시 기존 페이지를 다시 만들지 않고 Upsert한다.
- Parent Relation만 실패했다면 페이지 본문을 다시 생성하지 말고 Relation만 재시도한다.
- Notion MCP가 연결되지 않았다면 manifest와 Markdown을 그대로 보존하고 저장 실패를 명확히 알린다.

---

## 13. 사용자 호출 문구

### 최초 DB 설정

```text
notion-prd-publisher의 초기 설정을 진행해줘.
이 Notion 페이지 아래에 PRDs 데이터베이스를 만들거나 기존 DB를 검증해줘:
{Notion 상위 페이지 또는 DB URL}
```

### 최종 PRD 발행

```text
방금 확정한 PRD를 Notion에 발행해줘.
서비스: Canvas
상태: Review
모드: Upsert
Wiki: {URL}
Figma: {URL}
발행 전에 문서 트리와 생성·업데이트 예정 건수를 보여줘.
```

### 기존 PRD 업데이트

```text
수정된 PRD를 기존 Notion 문서에 업데이트해줘.
대상: {Notion PRD URL}
서비스: Canvas
상태: Review
새 페이지를 만들지 말고 Update 모드로 처리해줘.
```

### 발행만 수행하도록 제한

```text
PRD의 내용이나 문서 경계를 다시 판단하지 마.
입력된 documents와 parent_key를 그대로 사용하고 Notion 발행만 수행해줘.
```

