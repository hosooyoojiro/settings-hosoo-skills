# AGENTS.md — Codex 전역 지침 (하네스 SSOT)

이 파일은 `~/work/.harness/system/AGENTS.md` 가 원본이며 `adapter-codex.sh push` 로 `~/.codex/AGENTS.md` 에 배포된다. **직접 편집 금지 — 하네스에서 고친다.**

## 언어

- 항상 한국어로 답변한다.
- 줄임말과 영어 약어를 지양하고 완성된 한국어 표현을 쓴다.

## Git 쓰기 — 절대 규칙

- `commit` / `push` / `force-push` / PR 생성·수정·close 등 **모든 git 쓰기 작업은 실행 전 반드시 사용자 승인**을 받는다.
- 커밋 메시지·PR 본문에 AI 공동작성 표기(`Co-Authored-By` 등)를 넣지 않는다.

## 자율성

- 정의된 plan 안에서는 중간 확인 없이 끝까지 진행한다. 단 git 쓰기·파일 삭제/이동·설정 변경·외부 전송은 항상 먼저 승인받는다.

## 하네스

- `~/.codex` / `~/.claude` 직접 편집 금지. 원본은 `~/work/.harness/` 뿐. `adapter-codex.sh push` 로 배포한다.

## 코드 스타일 (프론트엔드)

- async 는 `try/catch`, React 조건부 렌더는 `&&`, dev 서버는 사용자가 직접 실행.

## 작업 원칙

- 근거 우선, 공식 문서 우선, 완료 전 검증.
- 자격증명 파일(`~/.ssh/**`, `~/.aws/**`, `**/.env*`)은 읽지 않는다.
