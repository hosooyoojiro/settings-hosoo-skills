#!/usr/bin/env bash
#
# harness-lib.sh — adapter 공유 로직 (status / push).
# adapter-claude.sh / adapter-codex.sh 가 source 해서 쓴다.
#
# 사용 규약:
#   HARNESS_ROOT  : 하네스 리포 루트
#   TARGET_HOME   : 배포 대상 홈 (~/.claude 또는 ~/.codex)
#   ADAPTER_NAME  : 로그용 이름
#   MAP           : 배포 매핑 배열. 각 항목 "type|src|dst"
#                   type = tree(디렉토리 미러 --delete) | file(단일 파일) | persona(role .md → skills/<name>/SKILL.md)
#
set -euo pipefail

_rsync() { rsync -a --exclude '.DS_Store' "$@"; }

# status: 무엇이 바뀌는지만 출력 (실배포 없음)
harness_status() {
  local diff_flag="" only_skill=""
  for a in "$@"; do
    case "$a" in
      --diff|--verbose) diff_flag="-i" ;;
      --skill) shift; only_skill="${1:-}" ;;
    esac
  done
  echo "▤ [$ADAPTER_NAME] status  ($TARGET_HOME)"
  local type src dst
  for entry in "${MAP[@]}"; do
    IFS='|' read -r type src dst <<<"$entry"
    _apply "$type" "$src" "$dst" "--dry-run --itemize-changes" "$only_skill"
  done
  echo "— 실제 배포: push"
}

# push: 실제 rsync 배포
harness_push() {
  local force="" only_skill=""
  while [ $# -gt 0 ]; do
    case "$1" in
      --force) force="1" ;;
      --skill) shift; only_skill="${1:-}" ;;
    esac
    shift
  done
  echo "▶ [$ADAPTER_NAME] push  ($TARGET_HOME)${only_skill:+  skill=$only_skill}${force:+  [force]}"
  local type src dst
  for entry in "${MAP[@]}"; do
    IFS='|' read -r type src dst <<<"$entry"
    _apply "$type" "$src" "$dst" "" "$only_skill" "$force"
  done
  echo "✓ 완료. 새 세션에서 인식됨."
}

# _apply <type> <src> <dst> <dryopts> <only_skill> <force>
_apply() {
  local type="$1" src="$2" dst="$3" dry="$4" only="${5:-}" force="${6:-}"
  case "$type" in
    tree)
      [ -e "$src" ] || return 0
      if [ -n "$only" ]; then
        # 단일 스킬만: src/<only>/ → dst/<only>/
        [ -d "${src}${only}" ] || return 0
        mkdir -p "${dst}${only}"
        echo "  tree*  ${src}${only}  ⇒  ${dst}${only}"
        _rsync --delete $dry "${src}${only}/" "${dst}${only}/"
      else
        mkdir -p "$dst"
        echo "  tree   $src  ⇒  $dst"
        _rsync --delete $dry "$src" "$dst"
      fi
      ;;
    file)
      [ -e "$src" ] || return 0
      [ -n "$only" ] && return 0   # 파일 매핑은 --skill 대상 아님
      echo "  file   $src  ⇒  $dst"
      _rsync $dry "$src" "$dst"
      ;;
    render)
      # __HARNESS_ROOT__ 을 실제 하네스 경로로 치환 후 배포 (경로 독립성).
      [ -e "$src" ] || return 0
      [ -n "$only" ] && return 0
      echo "  render $src  ⇒  $dst  (__HARNESS_ROOT__→$HARNESS_ROOT)"
      if [ -z "$dry" ]; then
        local tmp; tmp="$(mktemp)"
        sed "s|__HARNESS_ROOT__|${HARNESS_ROOT}|g" "$src" > "$tmp"
        _rsync "$tmp" "$dst"
        rm -f "$tmp"
      fi
      ;;
    persona)
      # role/*.md → dst/<name>/SKILL.md  (Codex: 페르소나를 스킬로)
      [ -d "$src" ] || return 0
      local f name
      for f in "$src"*.md; do
        [ -e "$f" ] || continue
        name="$(basename "$f" .md)"
        [ -n "$only" ] && [ "$only" != "$name" ] && continue
        mkdir -p "${dst}${name}"
        echo "  persona $f  ⇒  ${dst}${name}/SKILL.md"
        _rsync $dry "$f" "${dst}${name}/SKILL.md"
      done
      ;;
  esac
}

harness_dispatch() {
  local cmd="${1:-}"; shift || true
  case "$cmd" in
    status) harness_status "$@" ;;
    push)   harness_push "$@" ;;
    *) echo "사용법: $ADAPTER_NAME {status [--diff] | push [--skill <name>] [--force]}"; exit 1 ;;
  esac
}
