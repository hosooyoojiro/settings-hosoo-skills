# 새 컴퓨터 설치 가이드

이 하네스를 다른 컴퓨터에 동일하게 설치하는 방법. 사용법 전반은 [../README.md](../README.md).

## 원커맨드 설치

```bash
git clone https://github.com/CastleJun/setting-for-Harness.git ~/work/.harness
cd ~/work/.harness
cp secrets/tokens.env.example secrets/tokens.env   # ← 토큰 채우기 (아래 표)
bash install.sh
```

> **경로 주의**: 반드시 `~/work/.harness` 에 clone. 배포 시 훅 경로가 실제 위치로 자동 치환되지만(`__HARNESS_ROOT__` render), 이 경로를 기본 전제로 문서/설정이 작성돼 있음.

`install.sh` 단계:

| 단계 | 내용 | 자동/수동 |
|------|------|-----------|
| [0/5] 전제 도구 | node·claude·codex 설치(없으면) | 자동(best-effort) |
| [1/5] 미리보기 | 배포될/삭제될 항목 확인 → y 확인 | 자동 |
| [2/5] push | 스킬·role·command·system → Claude/Codex | 자동 |
| [3/5] HUD | claude-hud 플러그인 설치 | 자동 |
| [4/5] MCP | `~/.claude.json` 에 MCP 주입(토큰 치환) | 자동(토큰 있으면) |

## 어쩔 수 없이 수동인 것

1. **`secrets/tokens.env` 작성** — 실토큰은 git 에 안 올림(gitignore). 아래 표 참고.
2. **figma-bridge Figma 플러그인 임포트** — figma-bridge MCP 를 쓸 때만. [릴리스](https://github.com/gethopp/figma-mcp-bridge/releases)에서 플러그인 다운로드 → Figma `Plugins > Development > Import plugin from manifest` → `manifest.json` 선택 → 파일에서 플러그인 열기(자동 연결).
3. 위 [0/5] 자동설치가 실패하는 환경이면 node/claude/codex 를 수동 설치.

## 채울 토큰 (secrets/tokens.env)

| 변수 | 무엇 | 발급처 | 형식 | 필요 스코프 |
|------|------|--------|------|-------------|
| `SUPABASE_ACCESS_TOKEN` | Supabase 계정 관리(Management) 토큰. supabase MCP 가 사용. | https://supabase.com/dashboard/account/tokens (Account → Access Tokens → Generate) | `sbp_...` | 계정 전체(프로젝트 조회·SQL·관리) |

- 현재 global MCP 에서 **토큰이 필요한 건 supabase 하나뿐**이다. 안 넣으면 supabase MCP 만 안 되고 나머지는 정상.
- `GITHUB_PAT` 는 github MCP 를 global 로 추가할 때만 필요(현재 미사용). `tokens.env.example` 주석 참고.

> ⚠ Supabase 토큰은 **계정 레벨**이라 유출 시 영향이 큼. `tokens.env` 는 git 에 올리지 않는다(이미 `.gitignore`). 노출되면 즉시 재발급(rotate).

### 브라우저 OAuth (atlassian · notion)

- 토큰이 아니라 **최초 사용 시 브라우저 로그인**. install.sh 로 자동화 불가(인터랙티브).
- 해당 MCP 를 처음 호출하면 Claude Code 가 **브라우저를 자동으로 띄운다**(또는 `/mcp` 로 직접 인증). 로그인·승인만 수동.
- 인증 결과는 로컬에 저장되며 git 에 안 올라감 → 컴퓨터마다 1회.

## MCP 서버 목록 (system/mcp/mcp-servers.json)

| 이름 | 종류 | 토큰 필요 | 비고 |
|------|------|-----------|------|
| supabase | http | `SUPABASE_ACCESS_TOKEN` | |
| atlassian | sse | 없음(OAuth) | 최초 사용 시 브라우저 인증 |
| notion | http | 없음(OAuth) | 최초 사용 시 브라우저 인증 |
| figma-bridge | stdio(npx) | 없음 | Figma 플러그인 임포트 필요(위 참고) |

- `apply-mcp.sh` 는 **추가/갱신만** 함(삭제 안 함). MCP 를 빼려면 `~/.claude.json` 에서 수동 제거.

## 재배포(resync)

하네스 편집 후:

```bash
bash install.sh                                  # 전체 재실행
# 또는 배포만:
bash adapter/claude/bin/adapter-claude.sh push
bash adapter/codex/bin/adapter-codex.sh push
```
