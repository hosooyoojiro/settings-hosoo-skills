# .harness

- Claude Code / Codex 세션 하네스 SSOT.
- `~/.claude` / `$CODEX_HOME` 로 단방향 배포되는 rule / skill / role / plugin / memory 원본.
- 본 문서 = 사용법. 유지보수 = [MAINTENANCE.md](MAINTENANCE.md).

## 핵심 원칙

- **편집 대상 = `~/work/.harness/` 뿐.** `~/.claude` / `~/.codex` 직접 편집 금지 — PreToolUse 가드 훅이 차단하며 다음 push 에서 휘발된다.
- **harness = 유일 진실원.** `push` 는 rsync `--delete` 미러링이라 harness 에 없는 스킬은 배포 시 삭제된다. 두고 싶으면 반드시 리포에 vendor.
- **관리 트리만 배포.** `plugins/` · `projects/`(메모리) · `cache/` 는 건드리지 않는다.

## 동기화

- 하네스 편집 후 배포는 수동 push. 순서 = `status` 로 의도한 변경만 확인 → `push`.

```
bash adapter/claude/bin/adapter-claude.sh status [--diff|--verbose]
bash adapter/claude/bin/adapter-claude.sh push [--skill <name>] [--force]
bash adapter/codex/bin/adapter-codex.sh status [--diff|--verbose]
bash adapter/codex/bin/adapter-codex.sh push [--skill <name>] [--force]
```

### 배포 매핑

| 소스 | Claude | Codex |
|------|--------|-------|
| `skill/` | `~/.claude/skills/` | `~/.codex/skills/` (마크다운 그대로) |
| `role/*.md` | `~/.claude/agents/` (서브에이전트) | `~/.codex/skills/<name>/SKILL.md` (스킬) |
| `command/` | `~/.claude/commands/` | — |
| `system/CLAUDE.md` | `~/.claude/CLAUDE.md` | — |
| `system/AGENTS.md` | — | `~/.codex/AGENTS.md` |
| `system/settings.json` | `~/.claude/settings.json` | — |
| `system/hooks.json` | — | `~/.codex/hooks.json` |

- Codex 는 스킬·룰을 마크다운 그대로 읽는다. `.toml` 변환 불필요. `~/.codex/agents/*.toml` 는 OMC 잔재로 재구축 대상 아님.

## 신규 스킬 (grill-me v1.2 등)

에디터블 설치 → 리포로 vendor → 커밋 → push:

```
npx skills@latest add mattpocock/skills   # ~/.agents/skills/ 에 설치
cp -R ~/.agents/skills/grill-me skill/     # 리포로 vendor
git add -A && git commit -m "add grill-me v1.2"
bash adapter/claude/bin/adapter-claude.sh push
bash adapter/codex/bin/adapter-codex.sh push
```

## 새 컴퓨터 세팅 (원커맨드)

```
git clone https://github.com/CastleJun/setting-for-Harness.git ~/work/.harness
cd ~/work/.harness
cp secrets/tokens.env.example secrets/tokens.env   # 실토큰 채우기
bash install.sh
```

`install.sh` 가 하는 일: **전제 도구(node·claude·codex) 자동 설치** → 배포 미리보기 → 확인 → Claude/Codex push → claude-hud HUD 플러그인 설치 → MCP를 `~/.claude.json` 에 주입(토큰 자동 치환).

**어쩔 수 없이 수동인 것 3개:** (1) 위 자동설치가 실패하는 환경이면 node/claude/codex 수동 설치, (2) `secrets/tokens.env` 작성(아래), (3) figma-bridge 쓸 경우 Figma 플러그인 GUI 임포트.

### secrets/tokens.env

- 위치: `secrets/tokens.env` (git 제외). 템플릿: `secrets/tokens.env.example` (git 포함).
- 새 컴퓨터: `cp secrets/tokens.env.example secrets/tokens.env` → 실토큰 채움 → `install.sh` 가 `~/.claude.json` 에 자동 주입.

- **경로 독립**: 훅 경로는 배포 시 실제 하네스 위치로 자동 치환(`render`)되고, 가드 훅은 자기 위치로 루트를 계산한다. 그래도 `~/work/.harness` 권장.
- **MCP**: `secrets/tokens.env`(git 제외)에 토큰을 넣으면 `lib/apply-mcp.sh` 가 `system/mcp/mcp-servers.json` 을 `~/.claude.json` 에 병합. tokens.env 없으면 MCP만 건너뜀.
- **재배포(resync)**: 하네스 편집 후 다시 `bash install.sh` 또는 `adapter-*.sh push`.

## 채번

```
bash lib/next-number/bin/next-number.sh
```

- counter.json 과 `00.quest/` 파일명 scan-max 의 이중 fallback.

## 디렉토리 구조

| 경로 | 용도 |
|------|------|
| `skill/` | 스킬 (`{name}/SKILL.md`) — Claude·Codex 공통 마크다운 |
| `role/` | sub-agent persona SSOT (Claude agents / Codex skills 로 배포) |
| `command/` | Claude 슬래시 커맨드 |
| `plugin/` | Claude Code plugin (hook: `plugin/hooks/guard-write.sh`) |
| `memory/` | global 영구 + project 임시 메모 + 관리 규칙 |
| `system/` | 시스템 룰 SSOT (CLAUDE.md / AGENTS.md / settings.json / hooks.json / mcp) |
| `adapter/` | claude / codex 배포 CLI |
| `lib/` | 공유 스크립트 (harness-lib, next-number) |
| `daemon/` | launchd 상주 데몬 |
| `test/` | 하네스 스크립트 smoke test |
| `docs/` | 하네스 설계 문서 |

- 모듈별 상세 = 각 디렉토리의 `MAINTENANCE.md`.
