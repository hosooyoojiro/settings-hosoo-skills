#!/usr/bin/env bash
#
# guard-write.sh — PreToolUse 훅.
# agent 가 ~/.claude 또는 ~/.codex 를 "직접" 편집하지 못하게 차단한다.
# 모든 편집은 하네스 리포(~/work/.harness)에서 하고 deploy.sh 로 rsync 하는 규칙 강제.
#
# 등록(하네스 system/settings.json 안):
#   "hooks": {
#     "PreToolUse": [{
#       "matcher": "Write|Edit|MultiEdit",
#       "hooks": [{ "type": "command",
#                   "command": "bash ~/work/.harness/bin/guard-write.sh" }]
#     }]
#   }
#
# 규약: stdin 으로 훅 JSON 수신. 차단 시 exit 2 + stderr 사유.
set -euo pipefail

INPUT="$(cat)"

# tool_input.file_path 추출 (jq 있으면 jq, 없으면 grep 폴백)
if command -v jq >/dev/null 2>&1; then
  FP="$(printf '%s' "$INPUT" | jq -r '.tool_input.file_path // empty')"
else
  FP="$(printf '%s' "$INPUT" | grep -o '"file_path"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | sed 's/.*:[[:space:]]*"//; s/"$//')"
fi

[ -z "$FP" ] && exit 0   # 파일 경로 없는 툴콜은 통과

# ~ 및 상대경로 정규화
case "$FP" in
  "~/"*) FP="${HOME}/${FP#\~/}" ;;
esac

BLOCK=0
# 하네스가 "관리하는(=push 로 덮어쓰는)" 트리만 차단한다.
# projects/(메모리·세션 데이터) 등 런타임 데이터는 편집 허용.
case "$FP" in
  "${HOME}/.claude/skills/"*)   BLOCK=1 ;;
  "${HOME}/.claude/agents/"*)   BLOCK=1 ;;
  "${HOME}/.claude/commands/"*) BLOCK=1 ;;
  "${HOME}/.claude/CLAUDE.md")  BLOCK=1 ;;
  "${HOME}/.claude/settings.json") BLOCK=1 ;;
  "${HOME}/.codex/skills/"*)    BLOCK=1 ;;
  "${HOME}/.codex/agents/"*)    BLOCK=1 ;;
  "${HOME}/.codex/AGENTS.md")   BLOCK=1 ;;
  "${HOME}/.codex/hooks.json")  BLOCK=1 ;;
esac

# 하네스 내부 경로는 항상 허용 (스크립트 자기 위치로 하네스 루트 계산 → 경로 독립)
HARNESS_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." 2>/dev/null && pwd || true)"
case "$FP" in
  "${HARNESS_ROOT}/"*) BLOCK=0 ;;
esac

if [ "$BLOCK" = 1 ]; then
  echo "차단: 하네스 관리 경로 직접 편집 금지. 원본은 ~/work/.harness 에서 수정 후 'adapter-*.sh push' 로 배포하세요. (대상: $FP)" >&2
  exit 2
fi

exit 0
