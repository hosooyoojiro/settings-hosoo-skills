---
name: notion-prd-publisher
description: |
  완성되고 계층까지 확정된 PRD 문서를 Notion MCP로 `PRDs` 데이터베이스에 생성하거나 업데이트합니다.
  "PRD 발행", "notion-prd-publisher", "PRD를 노션에 올려줘", "PRD publish", "PRDs DB에 반영" 등의
  키워드가 있을 때 사용합니다. 이 스킬은 PRD 생성기가 아니며, Wiki/Figma 분석이나 단일/다중 구조 판단을
  하지 않습니다. 선행 워크플로우에서 확정된 문서 경계와 부모 관계를 그대로 Notion에 반영합니다.
---

# Notion PRD Publisher

완성된 PRD와 publication manifest를 받아 Notion `PRDs` 데이터베이스에 발행하는 스킬입니다.

전체 명세: [`reference/full-spec.md`](reference/full-spec.md)

## 발행 대상 (설정 완료 — 2026-07-15)

```yaml
workspace: dropshotai
parent_page: "🤫 Developers" (35b32a27fcc58058a353fa9ca94a2c55)
database_name: PRDs
database_url: https://app.notion.com/p/6c5be95ac2374280a4cadf757d0f39a7
data_source_url: collection://019d6d08-2cc5-4cb6-8bb6-3af2c810464b
default_view_id: a72e3400-440d-491f-a62a-88dd2e6c2210
schema_status: valid
```

발행/조회 시 위 `data_source_url`을 기본 대상으로 사용한다. 사용자가 다른 DB URL을 명시하면 그것을 우선한다.

**기본 뷰 설정:** 목록 뷰에서는 `Child PRDs`, `Figma`, `기획 Wiki`, `히스토리` 컬럼을 숨긴다(속성 자체는 유지, 표에서만 비표시). `수정일`은 표시 유지. 표시 컬럼: 제목 · 서비스 · 상태 · Parent PRD · Owner · 목표 일정 · 생성일 · 수정일. 뷰 컬럼 변경은 `update-view`의 `HIDE`/`SHOW` 디렉티브로 한다.

**스키마 주의 — `상태`는 Select 타입:** Notion Status 옵션은 API로 설정할 수 없어 `상태`를 Select로 생성했다. 옵션: `Draft / Review / Approved / In Development / Released / Archived`. Select이므로 없는 값을 쓰면 자동으로 새 옵션이 생기니, 위 6개 값만 정확히 사용한다.

### 관계(Parent PRD) 연결 방법 — 검증된 절차

- **부모 연결은 자식 쪽 `Parent PRD`에만 쓴다.** 값 포맷은 페이지 URL의 JSON 배열 문자열: `"[\"https://app.notion.com/p/<page_id>\"]"`. `Child PRDs`(역방향)는 Notion이 자동으로 채우므로 직접 쓰지 않는다.
- 발행 순서: ① 부모(루트) 페이지 먼저 생성 → ② 반환된 부모 page URL 확보 → ③ 자식 생성 시 `Parent PRD`에 부모 URL 지정(또는 생성 후 `update_properties`로 연결).
- **self-relation 생성 시 주의(설정 단계):** `update_data_source`로 자기참조 DUAL 관계를 만들 때는 **단일 문장**만 쓴다 — `ADD COLUMN "Parent PRD" RELATION('<ds_id>', DUAL 'Child PRDs' 'child_prds')`. 이러면 `Child PRDs`가 자동 생성된다. 두 컬럼을 각각 ADD하면 중복 쌍이 생기고, 그걸 DROP하면 DUAL 짝이 깨져 관계값·다른 셀까지 오염된다(실측 확인됨). 이미 이 DB는 올바른 단일 문장으로 구성돼 있다.

### 변경 이력 관리 — 별도 페이지 + `히스토리` URL 컬럼 (검증된 절차)

**변경 이력을 PRD 본문에 넣지 않는다.** 문서마다 별도 "변경 이력" 페이지를 두고, PRDs DB의 `히스토리` URL 컬럼으로 연결한다.

- 스키마: `히스토리`는 URL 타입 컬럼(이미 추가됨). 없을 때만 `update_data_source`로 `ADD COLUMN "히스토리" URL`.
- 히스토리 페이지: `parent_page`(Developers, `35b32a27fcc58058a353fa9ca94a2c55`) 하위에 `"<PRD 제목> — 변경 이력"` 페이지를 생성한다. 본문은 상단에 원본 PRD 링크 + 날짜별 변경 내용 표(`| 순서 | 변경 내용 |`).
- 연결: PRD 페이지의 `히스토리` 속성에 히스토리 페이지 URL을 넣는다(`update_properties`, 속성명 `히스토리`는 예약어 아님 — prefix 불필요).
- 갱신: 재발행 시 변경 내용은 **히스토리 페이지에만** 한 줄 추가하고, PRD 본문은 건드리지 않는다. PRD 본문 상단 메타에는 `변경 이력: [<제목> — 변경 이력](<url>)` 링크 한 줄만 유지.
- 다중 PRD: 문서(페이지)별로 각자 히스토리 페이지를 만들어 각 행의 `히스토리` 컬럼에 연결한다.

## 핵심 원칙

- **PRD 생성과 발행을 분리한다.** 이 스킬은 발행만 수행한다.
- 단일/다중 PRD 구조는 선행 단계에서 이미 확정된 것으로 본다. **자동 추론하지 않는다.**
- Markdown Heading을 근거로 문서를 자동 분리하지 않는다.
- 원문을 임의로 요약·재작성하지 않는다. 고정 템플릿(`문서 이력`, `개요` 등)을 강제하지 않는다.
- **변경 이력은 PRD 본문에 넣지 않는다.** 별도 "변경 이력" 페이지로 관리하고 `히스토리` URL 컬럼으로 연결한다(위 절차).
- 상위·하위 관계는 `Parent PRD` 자기참조 Relation으로만 표현한다.
- `PRDs` DB 하나만 사용한다. Projects DB나 PRD 유형 속성을 만들지 않는다.
- 문서 경계나 부모 관계가 불명확하면 Notion 쓰기 전에 입력 보완을 요청한다.

## 입력 계약

```yaml
service: Canvas          # 필수: AI Studio / Stock / Canvas / Match / Shared
status: Review           # 필수: Draft / Review / Approved / In Development / Released / Archived
mode: Upsert             # Create / Update / Upsert (기본 권장: Upsert)
wiki_url: ...            # 선택 (공통)
figma_url: ...           # 선택 (공통)
owner: ...               # 선택 (공통)
target_date: ...         # 선택 (공통)
documents:               # 필수
  - key: canvas-list     # 필수: manifest 내부 고유 식별자
    title: Canvas List   # 필수: Notion 페이지 제목
    body: |              # 필수: 완성된 Markdown PRD 본문
      ...
    parent_key: ...      # 선택: 부모 문서의 key
    wiki_url / figma_url / owner / target_date / status  # 선택: 문서별 override
    notion_url: ...      # 선택: 기존 PRD 정확 업데이트 대상
```

- 문서별 값이 없으면 최상위 공통값을 상속한다.
- `documents` 1건 → 단일 페이지. 여러 건 → 각각 별도 페이지.
- `parent_key`는 같은 manifest 안의 유효한 `key`를 참조해야 하며, 순환 참조를 허용하지 않는다.

## Notion `PRDs` DB 스키마

| 속성 | 타입 | 필수 |
|---|---|---|
| 제목 | Title | 필수 |
| 서비스 | Select (AI Studio/Stock/Canvas/Match/Shared) | 필수 |
| 상태 | Select (Draft/Review/Approved/In Development/Released/Archived) — ※ Status 옵션 API 미지원으로 Select 사용 | 필수 |
| Parent PRD | Self Relation → PRDs | 선택 |
| Child PRDs | 역방향 Relation | 자동 |
| Owner | Person | 선택 |
| 목표 일정 | Date | 선택 |
| 기획 Wiki | URL | 선택 |
| Figma | URL | 선택 |
| 히스토리 | URL (별도 "변경 이력" 페이지 링크) | 선택 |
| 생성일 / 수정일 | Created/Last edited time | 자동 |

의도적으로 만들지 않는 속성: Project Relation, PRD 유형, Main/Feature PRD 여부, PRD ID, 개요, 구현 계획, Ticket URL, 문서 버전. (변경 이력은 DB 내 리치텍스트 속성으로 만들지 않고, `히스토리` URL 컬럼 + 별도 페이지로 관리한다 — 위 "변경 이력 관리" 절차.)

## 실행 워크플로우

1. **입력 검증** — `service`/`status`/`documents`, 각 문서 `key`/`title`/`body`, key 중복, `parent_key` 유효성, 순환 참조 확인. 실패 시 Notion에 일부만 쓰지 말고 입력을 먼저 요청한다.
2. **PRDs DB 확인** — 대상 DB와 Select/Status 옵션 검증. 스키마가 다르면 자동 변경하지 않고 차이를 보고. 사용자가 명시 허용한 경우에만 누락 속성 추가.
3. **기존 PRD 검색** — 기본 키 `제목 + 서비스 + Parent PRD`. 0건→신규, 1건→모드에 따라 업데이트/경고, 2건 이상→후보 확인 요청(임의 선택 금지).
4. **부모부터 Upsert** — 루트 문서 먼저 생성/조회 → 페이지 ID를 key에 매핑 → 하위 문서 처리 → `Parent PRD` Relation 연결. 계층 순서대로 반복.
5. **본문 발행** — Markdown → Notion 블록 변환. 업데이트 시 기존 수동 내용을 임의 삭제하지 않고, 충돌 시 사용자 확인. **변경 이력은 본문에 넣지 않는다** — 상단 메타에 히스토리 페이지 링크 한 줄만 유지.
6. **변경 이력 페이지 연결 (공통)** — 각 PRD마다 별도 `<제목> — 변경 이력` 페이지를 `parent_page`(Developers) 하위에 생성/조회하고, PRD의 `히스토리` URL 속성에 연결한다. 재발행 시 변경 내용은 **히스토리 페이지에만** 한 줄 추가(PRD 본문 불변). 상세는 위 "변경 이력 관리 — 별도 페이지 + `히스토리` URL 컬럼" 절차.
7. **부모 본문에 하위 문서 링크 추가 (다중 PRD)** — 자식이 모두 생성/조회돼 페이지 URL이 확정되면, 부모(List/메인) PRD 본문 끝에 `## 하위 문서` 섹션을 추가하고 각 자식 PRD를 Notion 페이지 링크로 넣는다. `Parent PRD ↔ Child PRDs` 관계 속성과 별개로, **본문에서 바로 자식 문서로 이동**할 수 있게 하기 위함이다. 형식:

   ```markdown
   ## 하위 문서

   - [배너](https://app.notion.com/p/<child_page_id>)
   - [섹션 1](https://app.notion.com/p/<child_page_id>)
   ```

   재발행(Upsert) 시에는 기존 `## 하위 문서` 섹션을 새 목록으로 교체해 중복 추가를 막는다.
8. **결과 보고** — 생성/업데이트/건너뜀 수, Parent 연결 성공 여부, 히스토리 페이지 연결 여부, 실패 항목과 이유, Notion 링크.

### 발행 전 미리보기 (필수)

Notion에 쓰기 전 항상 문서 트리와 생성/업데이트/건너뜀 예정 건수를 보여주고 **한 번의 쓰기 확인**을 받는다. 사용자가 같은 요청에서 즉시 발행을 명시 승인했으면 반복 확인은 생략 가능. 구조나 대상 DB가 달라졌으면 반드시 다시 확인한다.

## Markdown → Notion 블록 변환

| Markdown | Notion |
|---|---|
| `## 제목` | Heading 1 |
| `### 제목` | Heading 2 |
| `#### 제목` | Heading 3 |
| 문단 | Paragraph |
| `- 항목` | Bulleted list |
| `1. 항목` | Numbered list |
| `- [ ] 항목` | To-do |
| Table | Table block |
| 인용/주의 | Quote / Callout |
| 코드 | Inline code / Code block |
| 링크 | URL 보존 Rich text |

보존 원칙: Heading 순서·표 행열·체크박스 상태·링크·미결정 사항을 유지한다. Notion 호환을 위한 최소 서식 정규화만 허용.

## 동작 모드

- **Create** — 동일 문서가 있으면 새로 만들지 않고 중복 후보 보고.
- **Update** — 기존 페이지가 정확히 1건일 때만 업데이트.
- **Upsert** (기본 권장) — 1건이면 업데이트, 없으면 생성.

## 오류 처리

- **Notion MCP 연결 실패** — manifest와 Markdown을 그대로 반환하고 저장 실패를 명확히 알린다. 가짜 링크 금지.
- **PRDs DB 미발견** — 생성 권한이 명시되면 정의된 스키마로 생성, 불명확하면 대상 DB/위치 요청.
- **Relation 실패** — 페이지 생성 성공과 Relation 실패를 분리 보고, 텍스트로 대체하지 않고 재시도용 링크 반환.
- **Manifest 불명확** — Heading으로 임의 분리하지 말고 선행 단계에서 구조를 다시 확정하도록 요청.

## 결과 보고 형식

```text
Notion 반영 완료

서비스: Canvas
구조:
- Canvas List
  - Banner
  - Section 1

작업: 생성 3 / 업데이트 0 / 건너뜀 0
Parent PRD 연결: 2/2 성공
링크:
- Canvas List: {URL}
- Banner: {URL}
- Section 1: {URL}
```

## 사용 도구

- Notion MCP: `mcp__notion__notion-search`, `notion-fetch`, `notion-query-data-sources`, `notion-create-pages`, `notion-update-page`, `notion-create-database`.
